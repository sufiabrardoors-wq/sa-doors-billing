S.A DOORS v1.4 — combined source update

The app id remains com.privateflushdoor.billing. Version is 1.3 (versionCode 4).

Preserved from the installed APK asset: door Sq.Ft. billing, Chemical/Mica/Sagwan/WPC door types, WPC thickness 24/25/28/30 mm, WPC Frame RFT, Sagwan Frame Nos., invoice history/edit/delete, party balance PDF, Cash/Bank books, backup/restore, and existing localStorage key sa_doors_business_v3.

Party screen update: separate Customers and Suppliers, customer/supplier cards, party balance report PDF, date-wise You Gave / You Got ledger, running balance, and transaction Edit/Delete with linked Cash/Bank synchronization safeguards.

Size chart: widths 22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,68,70 inches; heights 72,75,78,80,81,82,84,86,88,90,92,94 inches. Existing app rule rounds each dimension UP to the next available chart size; above the largest chart size it retains the entered dimension. Chart sizes can be added, edited and deleted. Full phone backup/restore includes both business records and customized size chart; old version-3 JSON backups remain restorable.

PDF paper defaults to A5 and generated PDF dimensions follow the selected paper size/orientation. PDF exports only; no CSV export controls. Google Drive cloud backup is not active until a Drive project and sign-in permissions are configured.

Signing migration: the build uses the previously generated permanent release keystore. Do not uninstall the currently installed app until you export and safely store a JSON backup and have downloaded the signed APK. The old installed debug-signed APK has a different certificate, so the first migration to this release key will require uninstall/reinstall. Future releases signed with this same keystore should update normally.


Version 1.4 additions in this source revision:
- All Customers Ledger PDF: one combined chronological ledger with per-customer running balances and total receivable.
- Payment due reminder list: pending invoices with customer, phone, due date and amount; can open WhatsApp share.
- Business summary PDF: invoice sales, receipts, payments, receivable and payable. It deliberately does not claim net profit because product purchase costs are not recorded separately.
- Global search across parties, invoices and cash/bank notes.
- Basic activity history records party creation, party transactions and invoice saves/edits. Existing older actions are not retroactively logged.

Important: this is an updated source package, not a built/tested APK. Build and on-device regression testing are still required. Google Drive backup remains unconfigured.
