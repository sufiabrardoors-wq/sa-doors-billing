S.A DOORS source update

Android app version: 1.5 (versionCode 6)
Existing source archive name and repository workflow path are preserved.

Changes in this update:
- Green colour for You Got / Payment received and Cash Book In entries.
- Red colour for You Gave / Payment made and Cash Book Out entries.
- Same green/red direction colours in individual party ledger PDF.
- Added All Parties Balance PDF for Customers and Suppliers together.
- Existing invoice, party ledger, chart and offline data structures retained.

Build: GitHub Actions workflow .github/workflows/build-apk.yml
Artifact: SA-DOORS-APK-v1.5
