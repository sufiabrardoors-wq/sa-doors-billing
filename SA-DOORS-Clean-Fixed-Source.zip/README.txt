S.A DOORS - Offline Android App Project

This project is designed to be built with the existing GitHub Actions workflow.

Included features:
- GST-free invoice builder with size/sq-ft calculation
- Flush, Chemical and WPC door types; thickness options 24/25/28/30 mm
- Invoice PDF/print bridge for Android
- Invoice history search, edit and delete actions
- Editing/deleting an invoice refreshes invoice-linked Khata transactions and linked book entries
- Party Khata, cash/bank/cheque book, opening balances, reports
- Home dashboard with today's invoices/sales and balances
- JSON backup/restore and CSV export
- Local offline storage; no cloud backup is configured

Important: Existing local app data is stored on the device. Export a backup before installing an upgraded build. Test edits/deletes with a backup or test invoice first. This source package has had JavaScript syntax checked but has not been fully device-tested in this environment.

Advanced ledger convenience additions:
- Share a party balance reminder via WhatsApp (opens WhatsApp/web with a prepared message; user reviews/sends it).
- Export the currently filtered party ledger as CSV for spreadsheet use.
These actions require the user to select a party. CSV and WhatsApp actions should be tested on the target Android WebView before production use.

WhatsApp / direct sharing upgrade:
- Invoice screen now includes Share Invoice PDF and WhatsApp Invoice buttons.
- Saved invoice PDF is generated and opened in Android's share sheet; choose WhatsApp or another app.
- WhatsApp Invoice opens WhatsApp with invoice number, date, customer and total prefilled as a message.
- Advanced Party Ledger includes Share Ledger PDF, which opens the Android share sheet for the generated statement PDF.
- Share buttons require the updated Android APK. If WhatsApp is installed, select it from the Android share menu. Text message sharing opens the WhatsApp conversation/message composer; the user must tap Send.


UPDATE: ADVANCED INVOICE SHARING
- Share Invoice PDF creates a PDF and opens Android share sheet.
- WhatsApp Invoice now attempts to share the actual invoice PDF attachment to WhatsApp with a ready-made message; if WhatsApp is unavailable, it falls back to Android share chooser.
- Party Ledger Share PDF uses the same PDF sharing flow.
- User must review and tap Send in WhatsApp; sending is never automatic.

TESTING NOTE
This source update has not been built and device-tested in this environment. Run the repository GitHub Actions workflow and test with a sample invoice before using for real business records. Back up data before updating.

Invoice making upgrade (v1.1):
- Invoice includes customer PO/reference, due date, and payment terms; these fields are saved and restored when editing an invoice and appear on the invoice preview/PDF.
- Invoice line items can be edited in place from the invoice preview, or removed after confirmation.
- Save rate for the selected door finish and thickness. The saved rate is recalled when selecting the same finish/thickness combination on this device.
- Existing door type, thickness, size-chart/actual area calculator, extra-per-door pricing, carriage, discount, previous balance, advance, invoice edit/delete, PDF printing and PDF sharing remain included.
- GST remains removed.

PDF FIX PACKAGE NOTES:
- This package has a single Android project at its root; it does not require nested ZIP extraction.
- Invoice PDF Save now creates a PDF document and writes it to the Android Downloads collection.
- Invoice and party ledger PDF share use a generated PDF file and Android share sheet; WhatsApp sharing targets WhatsApp first and falls back to the chooser.
- Print Invoice continues to use Android's print framework.
- GitHub Actions uses Java 17 and Gradle 8.9, compatible with Android Gradle Plugin 8.7.3.
- Build and device-test this package before using it for real business records. Export a JSON backup from the existing app first. Installing an app update with the same application ID and signing key is required to preserve app-private data; otherwise export/import backup.
