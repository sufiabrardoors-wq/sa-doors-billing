package com.privateflushdoor.billing;

import android.app.Activity;
import android.content.Context;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.view.View;
import android.view.ViewGroup;
import java.io.FileOutputStream;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF111111);
        getWindow().setNavigationBarColor(0xFF111827);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF5F5F5);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class PrintBridge {
        @JavascriptInterface public void printInvoice(final String html) {
            runOnUiThread(() -> {
                WebView printView = new WebView(MainActivity.this);
                printView.getSettings().setJavaScriptEnabled(false);
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager manager = (PrintManager)getSystemService(Context.PRINT_SERVICE);
                        if (manager != null) { String jobName = "S.A DOORS Invoice"; manager.print(jobName, view.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build()); }
                    }
                });
                printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }
    }

    private class ShareBridge {
        @JavascriptInterface public void openUrl(final String url) {
            runOnUiThread(() -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { showError("WhatsApp or a browser is not available."); } });
        }
        @JavascriptInterface public void sharePdf(final String html, final String requestedName) {
            createPdfForSharing(html, requestedName, false, "");
        }
        @JavascriptInterface public void sharePdfToWhatsApp(final String html, final String requestedName, final String message) {
            createPdfForSharing(html, requestedName, true, message == null ? "" : message);
        }
        private void createPdfForSharing(final String html, final String requestedName, final boolean whatsappOnly, final String message) {
            runOnUiThread(() -> {
                WebView.enableSlowWholeDocumentDraw();
                final WebView pdfView = new WebView(MainActivity.this);
                pdfView.getSettings().setJavaScriptEnabled(false);
                pdfView.setVerticalScrollBarEnabled(false);
                pdfView.setHorizontalScrollBarEnabled(false);
                pdfView.setWebViewClient(new WebViewClient() {
                    private boolean handled = false;
                    @Override public void onPageFinished(WebView view, String url) {
                        if (handled) return;
                        handled = true;
                        try {
                            int pageWidth = 595, pageHeight = 842;
                            int contentHeight = Math.max(pageHeight, (int)(view.getContentHeight() * view.getScale()));
                            view.measure(View.MeasureSpec.makeMeasureSpec(pageWidth, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(contentHeight, View.MeasureSpec.EXACTLY));
                            view.layout(0, 0, pageWidth, contentHeight);
                            String safeName = requestedName == null ? "SA-DOORS-Document.pdf" : requestedName.replaceAll("[^a-zA-Z0-9._-]", "_");
                            if (!safeName.toLowerCase().endsWith(".pdf")) safeName += ".pdf";
                            File outDir = new File(getCacheDir(), "shared-invoices");
                            if (!outDir.exists() && !outDir.mkdirs()) throw new IOException("Cannot create PDF folder");
                            File pdfFile = new File(outDir, safeName);
                            PdfDocument document = new PdfDocument();
                            int pages = Math.max(1, (contentHeight + pageHeight - 1) / pageHeight);
                            for (int i = 0; i < pages; i++) {
                                PdfDocument.Page page = document.startPage(new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, i + 1).create());
                                Canvas canvas = page.getCanvas();
                                canvas.save();
                                canvas.translate(0, -i * pageHeight);
                                canvas.clipRect(0, i * pageHeight, pageWidth, (i + 1) * pageHeight);
                                view.draw(canvas);
                                canvas.restore();
                                document.finishPage(page);
                            }
                            try (FileOutputStream out = new FileOutputStream(pdfFile)) { document.writeTo(out); }
                            document.close();
                            pdfView.destroy();
                            shareFile(pdfFile, whatsappOnly, message);
                        } catch (Exception e) {
                            pdfView.destroy();
                            showError("Could not create PDF. Please try again.");
                        }
                    }
                });
                pdfView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }
        private void shareFile(File file, boolean whatsappOnly, String message) {
            try {
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".provider", file);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                if (message != null && !message.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, message);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                send.setClipData(ClipData.newUri(getContentResolver(), "S.A DOORS PDF", uri));
                if (whatsappOnly) {
                    send.setPackage("com.whatsapp");
                    try { startActivity(send); }
                    catch (Exception missing) {
                        send.setPackage(null);
                        startActivity(Intent.createChooser(send, "Choose WhatsApp to share the invoice PDF"));
                    }
                } else startActivity(Intent.createChooser(send, "Share S.A DOORS PDF"));
            } catch (Exception e) { showError("Could not open sharing menu. Please try Print / Save PDF."); }
        }
        private void showError(String message) { runOnUiThread(() -> webView.evaluateJavascript("(function(){var n=document.getElementById('notice');if(n){n.textContent=" + org.json.JSONObject.quote(message) + ";n.classList.add('show');}})()", null)); }
    }

    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
