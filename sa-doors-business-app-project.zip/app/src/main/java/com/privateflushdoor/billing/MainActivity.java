package com.privateflushdoor.billing;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF3730A3);
        getWindow().setNavigationBarColor(0xFF111827);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF1F5F9);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class PrintBridge {
        @JavascriptInterface public void printInvoice(final String html) {
            runOnUiThread(() -> {
                WebView printView = new WebView(MainActivity.this);
                printView.getSettings().setJavaScriptEnabled(false);
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager manager = (PrintManager)getSystemService(Context.PRINT_SERVICE);
                        if (manager != null) { String jobName = "S.A DOORS Invoice"; manager.print(jobName, view.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build()); }
                    }
                });
                printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }
    }

    private class ShareBridge {
        @JavascriptInterface public void openUrl(final String url) {
            runOnUiThread(() -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { showError("WhatsApp or a browser is not available."); } });
        }
        @JavascriptInterface public void sharePdf(final String html, final String requestedName) {
            createPdfForSharing(html, requestedName, false, "");
        }
        @JavascriptInterface public void sharePdfToWhatsApp(final String html, final String requestedName, final String message) {
            createPdfForSharing(html, requestedName, true, message == null ? "" : message);
        }
        private void createPdfForSharing(final String html, final String requestedName, final boolean whatsappOnly, final String message) {
            runOnUiThread(() -> {
                WebView pdfView = new WebView(MainActivity.this);
                pdfView.getSettings().setJavaScriptEnabled(false);
                pdfView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        String safeName = requestedName == null ? "SA-DOORS-Invoice.pdf" : requestedName.replaceAll("[^a-zA-Z0-9._-]", "_");
                        if (!safeName.toLowerCase().endsWith(".pdf")) safeName += ".pdf";
                        File outDir = new File(getCacheDir(), "shared-invoices");
                        if (!outDir.exists()) outDir.mkdirs();
                        File pdfFile = new File(outDir, safeName);
                        PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(safeName);
                        PrintAttributes attrs = new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
                        CancellationSignal signal = new CancellationSignal();
                        adapter.onLayout(null, attrs, signal, new PrintDocumentAdapter.LayoutResultCallback() {
                            @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                                try {
                                    ParcelFileDescriptor fd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_READ_WRITE);
                                    adapter.onWrite(new android.print.PageRange[]{android.print.PageRange.ALL_PAGES}, fd, signal, new PrintDocumentAdapter.WriteResultCallback() {
                                        @Override public void onWriteFinished(android.print.PageRange[] pages) { try { fd.close(); shareFile(pdfFile, whatsappOnly, message); } catch (IOException e) { showError("Could not prepare PDF for sharing."); } }
                                        @Override public void onWriteFailed(CharSequence error) { try { fd.close(); } catch (Exception ignored) {} showError("PDF creation failed. Try Print / Save PDF instead."); }
                                    });
                                } catch (IOException e) { showError("Could not create invoice PDF."); }
                            }
                            @Override public void onLayoutFailed(CharSequence error) { showError("Could not lay out invoice PDF."); }
                        }, null);
                    }
                });
                pdfView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }
        private void shareFile(File file, boolean whatsappOnly, String message) {
            try {
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".provider", file);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                if (message != null && !message.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, message);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (whatsappOnly) {
                    send.setPackage("com.whatsapp");
                    try { startActivity(send); }
                    catch (Exception missing) {
                        send.setPackage(null);
                        startActivity(Intent.createChooser(send, "Choose WhatsApp to share the invoice PDF"));
                    }
                } else startActivity(Intent.createChooser(send, "Share S.A DOORS PDF"));
            } catch (Exception e) { showError("Could not open sharing menu. Please try Print / Save PDF."); }
        }
        private void showError(String message) { runOnUiThread(() -> webView.evaluateJavascript("(function(){var n=document.getElementById('notice');if(n){n.textContent=" + org.json.JSONObject.quote(message) + ";n.classList.add('show');}})()", null)); }
    }

    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
