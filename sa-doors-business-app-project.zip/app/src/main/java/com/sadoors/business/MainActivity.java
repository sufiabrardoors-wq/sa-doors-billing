package com.sadoors.business;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.content.*;
import android.print.*;
import android.net.Uri;
import java.io.*;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); setContentView(web); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.addJavascriptInterface(new Bridge(),"Android"); web.loadUrl("file:///android_asset/index.html"); }
  public class Bridge {
    @JavascriptInterface public void printPage(){runOnUiThread(()->{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE); pm.print("S.A DOORS",web.createPrintDocumentAdapter("S.A DOORS"),new PrintAttributes.Builder().build());});}
    @JavascriptInterface public void shareText(String text){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Share"));});}
    @JavascriptInterface public void backup(String data){try{File f=new File(getExternalFilesDir(null),"SADOORS-backup.json");try(FileWriter w=new FileWriter(f)){w.write(data);} }catch(Exception e){}}
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
