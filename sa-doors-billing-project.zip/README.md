# S.A DOORS Billing App (starter)

This is a clean Android WebView wrapper around the provided offline HTML billing calculator.

## Build APK
Push this project to the `main` branch, then open **Actions → Build S.A DOORS APK → Run workflow**. When successful, download the `SA-DOORS-debug-APK` artifact.

## Important
- This starter packages the existing HTML calculator. It does not yet implement every requested feature (Khata, cash/bank books, reports, PIN lock, etc.).
- Test billing calculations and PDF/print behavior on your phone before using it for business records.
- Local app data may be lost if the app is uninstalled or its storage is cleared. Keep backups.
