S.A DOORS source update

Build: GitHub Actions workflow .github/workflows/build-apk.yml
Output artifact: SA-DOORS-APK

Invoice line items display the exact entered width and height. Chart-rounded dimensions remain used for square-foot calculation and billing. Invoice print/PDF is A5 portrait. CSV export features are removed; backups remain JSON for complete restore. Party balance PDF and ledger PDF are retained.
