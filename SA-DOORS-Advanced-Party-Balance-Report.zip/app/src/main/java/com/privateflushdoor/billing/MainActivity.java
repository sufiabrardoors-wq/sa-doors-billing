package com.privateflushdoor.billing;

import android.app.Activity;
import android.content.Context;
import android.content.ContentValues;
import android.os.Build;
import android.provider.MediaStore;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF111111);
        getWindow().setNavigationBarColor(0xFF111827);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF5F5F5);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class PrintBridge {
        @JavascriptInterface public void printInvoice(final String html) {
            runOnUiThread(() -> {
                WebView printView = new WebView(MainActivity.this);
                printView.getSettings().setJavaScriptEnabled(false);
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager manager = (PrintManager)getSystemService(Context.PRINT_SERVICE);
                        if (manager != null) { String jobName = "S.A DOORS Invoice"; manager.print(jobName, view.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build()); }
                    }
                });
                printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }
    }

    private class ShareBridge {
        @JavascriptInterface public void openUrl(final String url) {
            runOnUiThread(() -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { showError("WhatsApp or a browser is not available."); } });
        }
        @JavascriptInterface public void sharePdf(final String html, final String requestedName) {
            createPdfForSharing(html, requestedName, false, "", false);
        }
        @JavascriptInterface public void savePdf(final String html, final String requestedName) {
            createPdfForSharing(html, requestedName, false, "", true);
        }
        @JavascriptInterface public void saveCsv(final String requestedName, final String csv) {
            runOnUiThread(() -> {
                try {
                    String name = requestedName == null ? "SA-DOORS-transactions.csv" : requestedName.replaceAll("[^a-zA-Z0-9._-]", "_");
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv");
                    if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Files.getContentUri("external"), values);
                    if (uri == null) throw new IOException("Download location unavailable");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new IOException("Cannot open download");
                        out.write((csv == null ? "" : csv).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    }
                    showError("CSV saved in Downloads: " + name);
                } catch (Exception e) { showError("CSV export failed. Please try again."); }
            });
        }
        @JavascriptInterface public void sharePdfToWhatsApp(final String html, final String requestedName, final String message) {
            createPdfForSharing(html, requestedName, true, message == null ? "" : message, false);
        }
        private void createPdfForSharing(final String html, final String requestedName, final boolean whatsappOnly, final String message, final boolean saveToDownloads) {
            runOnUiThread(() -> {
                final WebView pdfView = new WebView(MainActivity.this);
                pdfView.getSettings().setJavaScriptEnabled(false);
                pdfView.setBackgroundColor(android.graphics.Color.WHITE);
                pdfView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        try {
                            final int pageWidth = 794;
                            final int pdfWidth = 595;
                            final int pdfHeight = 842;
                            view.measure(
                                android.view.View.MeasureSpec.makeMeasureSpec(pageWidth, android.view.View.MeasureSpec.EXACTLY),
                                android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED)
                            );
                            int contentHeight = Math.max(view.getMeasuredHeight(), 1);
                            view.layout(0, 0, pageWidth, contentHeight);
                            float scale = (float) pdfWidth / (float) pageWidth;
                            int pageContentHeight = Math.max(1, (int) (pdfHeight / scale));
                            android.graphics.pdf.PdfDocument document = new android.graphics.pdf.PdfDocument();
                            int pageCount = Math.max(1, (contentHeight + pageContentHeight - 1) / pageContentHeight);
                            for (int pageNumber = 0; pageNumber < pageCount; pageNumber++) {
                                android.graphics.pdf.PdfDocument.PageInfo info = new android.graphics.pdf.PdfDocument.PageInfo.Builder(pdfWidth, pdfHeight, pageNumber + 1).create();
                                android.graphics.pdf.PdfDocument.Page page = document.startPage(info);
                                android.graphics.Canvas canvas = page.getCanvas();
                                canvas.save();
                                canvas.scale(scale, scale);
                                canvas.translate(0, -pageNumber * pageContentHeight);
                                canvas.clipRect(0, pageNumber * pageContentHeight, pageWidth, (pageNumber + 1) * pageContentHeight);
                                view.draw(canvas);
                                canvas.restore();
                                document.finishPage(page);
                            }
                            String safeName = requestedName == null ? "SA-DOORS-Invoice.pdf" : requestedName.replaceAll("[^a-zA-Z0-9._-]", "_");
                            if (!safeName.toLowerCase().endsWith(".pdf")) safeName += ".pdf";
                            File outDir = new File(getCacheDir(), "shared-invoices");
                            if (!outDir.exists() && !outDir.mkdirs()) throw new IOException("Cannot create PDF folder");
                            File pdfFile = new File(outDir, safeName);
                            try (OutputStream out = new java.io.FileOutputStream(pdfFile)) { document.writeTo(out); }
                            document.close();
                            if (saveToDownloads) savePdfToDownloads(pdfFile);
                            else shareFile(pdfFile, whatsappOnly, message);
                        } catch (Exception e) {
                            showError("Could not create invoice PDF. Please try Print / Save PDF instead.");
                        } finally {
                            view.destroy();
                        }
                    }
                });
                pdfView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }
        private void savePdfToDownloads(File file) {
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, file.getName());
                values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Files.getContentUri("external"), values);
                if (uri == null) throw new IOException("Download location unavailable");
                try (InputStream in = new FileInputStream(file); OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Cannot open download");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                }
                showError("PDF saved in Downloads: " + file.getName());
            } catch (Exception e) { showError("Could not save PDF to Downloads."); }
        }
        private void shareFile(File file, boolean whatsappOnly, String message) {
            try {
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".provider", file);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                if (message != null && !message.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, message);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (whatsappOnly) {
                    send.setPackage("com.whatsapp");
                    try { startActivity(send); }
                    catch (Exception missing) {
                        send.setPackage(null);
                        startActivity(Intent.createChooser(send, "Choose WhatsApp to share the invoice PDF"));
                    }
                } else startActivity(Intent.createChooser(send, "Share S.A DOORS PDF"));
            } catch (Exception e) { showError("Could not open sharing menu. Please try Print / Save PDF."); }
        }
        private void showError(String message) { runOnUiThread(() -> webView.evaluateJavascript("(function(){var n=document.getElementById('notice');if(n){n.textContent=" + org.json.JSONObject.quote(message) + ";n.classList.add('show');}})()", null)); }
    }

    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
